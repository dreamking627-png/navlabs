# NavLab
Private live mutual-fund NAV estimator (backend-first).

## Run
    pip install -r requirements.txt
    uvicorn app.main:app --reload          # open http://localhost:8000
    NAVLAB_SOURCES=fake uvicorn app.main:app   # demo without internet (fake prices, labelled DEMO)
    pytest

## Fetch holdings (once or twice a month)
Rupeevest schemecode is **not** the AMFI code. Look up the 6-digit AMFI code in `refined/schemes.csv`.

    python fetch_fund.py 45529 \
      --name "SBI Nifty Next 50 Index Fund Direct Growth" \
      --amfi 148945 \
      --category "Equity,Index" \
      --plan Direct --option Growth --type Index \
      --out data/funds/sbi-nifty-next-50-dg.yaml

Then restart the app so the importer loads the new YAML.

## Before real use (fill in / verify)
1. Set previous official NAV: `POST /api/funds/{id}/nav {"date":"YYYY-MM-DD","nav":"12.3456"}` (or wire daily AMFI file).
2. For FoFs: set `underlying_etf.symbol` in the YAML for the ETF cross-check.
3. Yahoo/NSE adapters are unofficial. Prefer yfinance or a paid source for anything you rely on.

## Extend without code changes
- New fund / new month of holdings: run `fetch_fund.py` (or hand-edit a YAML in `data/funds`) and restart. Weights must sum ~100% and every row needs an NSE symbol.
- New category: `category: [Parent, Child]` in the fund file.
- New tax rule or cost: new dated entry. New source: one class in `app/sources.py` + REGISTRY line + `config/sources.yaml` order.

See **MEMORY.md** for full project status, schema, API, and known gaps.
